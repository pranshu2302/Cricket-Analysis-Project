# Cricket_Analysis_Project
Analysis of performance of players in ODI Cricket

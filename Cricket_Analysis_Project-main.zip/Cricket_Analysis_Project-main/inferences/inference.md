Contains inferences gained from analysis of the results from the code.

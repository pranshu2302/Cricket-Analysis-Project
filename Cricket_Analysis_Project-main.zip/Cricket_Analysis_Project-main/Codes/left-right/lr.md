Contains the left-right batsman pair.

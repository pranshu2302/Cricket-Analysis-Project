Contains all the analysis files from the perspective of the bowlers.

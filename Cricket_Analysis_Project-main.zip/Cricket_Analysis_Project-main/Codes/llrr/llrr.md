Containing left-left & right-right batsmen.
